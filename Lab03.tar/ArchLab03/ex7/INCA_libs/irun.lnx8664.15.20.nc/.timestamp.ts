1636465093 /data.cc/data/a/home/cc/students/cs/omri/ArchLab03/ex7/sat_count.v
1637048307 /data.cc/data/a/home/cc/students/cs/omri/ArchLab03/ex7/sat_count_tb.v
