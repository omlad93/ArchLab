1636446709 /data.cc/data/a/home/cc/students/cs/omri/ArchLab03/ex3/fulladder.v
1636446709 /data.cc/data/a/home/cc/students/cs/omri/ArchLab03/ex3/fulladder_tb.v
